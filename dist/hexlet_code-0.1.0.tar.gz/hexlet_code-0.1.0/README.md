### Hexlet tests and linter status:

[![Actions Status](https://github.com/WhiskeyBisquit/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/WhiskeyBisquit/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/e4a11d3d8606b89ef17b/maintainability)](https://codeclimate.com/github/WhiskeyBisquit/python-project-49/maintainability)
